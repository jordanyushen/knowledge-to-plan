# 运行环境与时区数据

## 生成端

脚本使用 Python 3.9+ 的 `zoneinfo`，3.9 是语法与标准库兼容下限。本机已验证 Python 3.9.6；其他版本与平台以仓库 CI 的实际结果为准。新安装建议使用仍获 Python 官方维护的版本，不把兼容下限当作推荐安装版本。

生成前，在准备运行脚本的同一 Python 环境安装依赖：

```bash
python -m pip install -r <skill-dir>/requirements.txt
```

macOS/Linux 上若实际使用的命令为 `python3`，以上命令也相应使用 `python3 -m pip`。可使用虚拟环境，无需全局安装或管理员权限。

`tzdata` 是生成时依赖，提供 IANA 时区数据库。`zoneinfo` 优先读取系统数据库，在没有系统数据时读取 `tzdata`；Windows 常需要后者。即使没有请求 ICS，课程校验仍需要检查 `course.timezone`，因此也要有可用的时区数据。[Python 官方说明](https://docs.python.org/3/library/zoneinfo.html#data-sources)

遇到环境缺少时区数据库的错误，先安装 `tzdata`；遇到时区名称不在可用数据库中的错误，核对 `Asia/Hong_Kong` 等名称，必要时在同一环境执行 `python -m pip install --upgrade tzdata`。局部或过期数据库也可能缺少合法名称，不能单凭一次查找失败断言名称永久无效。脚本不会改用 UTC 或系统默认时区。

ICS 使用课程指定时区计算实际时间。遇到夏令时跳变中不存在或存在两个解释的当地时刻，需要选择明确时刻，生成器会在写入产物前报错。

## 开发与验证端

Python 单元测试使用同一生成环境和依赖。Node.js 只用于运行模板的开发测试，不参与生成脚本或学习页面运行。新增浏览器测试依赖也只属于开发环境。最低 Node 版本与浏览器支持范围应随实际 CI 和浏览器测试证据记录，不能根据一次高版本测试宣称覆盖所有低版本。

本次本机验证环境为 Python 3.9.6、Node.js v26.0.0。测试结果不替代教学内容、真实手机、Safari/Firefox 或其他未运行环境的验收。

## 学习端

学习者打开生成的 `index.html` 时，只需要支持页面功能的浏览器；不需要 Python、Node、`tzdata`、前端包管理器或服务器。课程内容、CSS 和 JavaScript 均内嵌，原文链接仍可能需要网络。

进度保存在当前浏览器和当前页面环境。浏览器限制本地存储时，页面会提示导出备份；不同设备、浏览器和在线/离线副本不会自动同步。本地 `file://` 与 HTTP 部署分别验证，不能相互替代。
